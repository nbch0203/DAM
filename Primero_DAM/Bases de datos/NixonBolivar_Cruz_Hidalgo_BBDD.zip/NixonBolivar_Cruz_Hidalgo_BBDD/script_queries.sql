use pccomp;
select nombre,email,fecha,precio_unitario,cantidad,total From clientes
Join pedidos on clientes.id=pedidos.cliente_id where clientes.id=20

    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;

use pccomp;
select categorias.nombre,productos.nombre,productos.precio,productos.stock
from productos
JOIN categorias on productos.categoria_id=categorias.id

    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;


use pccomp;
select productos.nombre,productos.precio,clientes.nombre From productos
join pedidos on productos.id=pedidos.producto_id
join clientes on pedidos.cliente_id=clientes.id
Join categorias on productos.categoria_id =categorias.id
where productos.precio >(
	Select avg(precio)
    from productos
    where categoria_id=productos.categoria_id
        /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
    );
    
use pccomp;
Select productos.nombre,productos.stock,categorias.nombre
From productos
join categorias on productos.categoria_id = categorias.id
where productos.stock <(
	select avg(stock)
    from productos
);

use pccomp;
select tiendas.nombre, count(productos.id)
from tiendas join inventario on tiendas.id =inventario.tienda_id
join productos on inventario.producto_id =productos.id
where productos.precio >(
	select avg (precio)
    from productos
)
group by tiendas.nombre
    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;

use pccomp;
select productos.nombre as producto, categorias.nombre as categorias
from productos
join categorias
on productos.categoria_id =categorias.id
    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;

use pccomp;
select tiendas.nombre as tienda, productos.nombre as producto
from tiendas
join inventario on tiendas.id =inventario.tienda_id
join productos on inventario.producto_id =productos.id
    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;

use pccomp;
SELECT categorias.nombre AS categoria, COUNT(productos.id) AS total_productos 
FROM categorias JOIN productos ON categorias.id = productos.categoria_id
GROUP BY categorias.nombre;

    /*Codigo SQL de Nixon Bolivar Cruz Hidalgo*/
;
