CREATE DATABASE PCCOMP;
USE PCCOMP;

-- Tabla de categorías
CREATE TABLE categorias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(35) NOT NULL
);

-- Tabla de productos
CREATE TABLE productos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(25) NOT NULL,
    descripcion VARCHAR(60),
    precio DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL,
    categoria_id INT,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabla de tiendas
CREATE TABLE tiendas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(25) NOT NULL,
    direccion VARCHAR(35) NOT NULL,
    telefono INT
);

-- Tabla de distribuidores
CREATE TABLE distribuidores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(35) NOT NULL,
    email VARCHAR(25),
    telefono INT
);

-- Tabla de inventario para relacionar productos con tiendas
CREATE TABLE inventario (
    id INT PRIMARY KEY AUTO_INCREMENT,
    producto_id INT,
    tienda_id INT,
    cantidad INT NOT NULL,
    FOREIGN KEY (producto_id) REFERENCES productos(id),
    FOREIGN KEY (tienda_id) REFERENCES tiendas(id)
);

-- Tabla de suministros para relacionar productos con distribuidores
CREATE TABLE suministros (
    id INT PRIMARY KEY AUTO_INCREMENT,
    producto_id INT,
    distribuidor_id INT,
    cantidad INT NOT NULL,
    FOREIGN KEY (producto_id) REFERENCES productos(id),
    FOREIGN KEY (distribuidor_id) REFERENCES distribuidores(id)
);

-- Tabla de clientes
CREATE TABLE clientes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(35) NOT NULL,
    email VARCHAR(35),
    telefono INT,
    direccion VARCHAR(35)
);

-- Tabla de pedidos
CREATE TABLE pedidos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT,
    fecha TIMESTAMP,
    total DECIMAL(10, 2) NOT NULL,
    producto_id INT,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Tabla de empleados
CREATE TABLE empleados (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(35) NOT NULL,
    puesto VARCHAR(20),
    tienda_id INT,
    FOREIGN KEY (tienda_id) REFERENCES tiendas(id)
);