package conexion;

import java.sql.Connection;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {
	private static String bd = "DBNixon";
	private static String login = "admin";
	private static String password = "Villaverde1.0";
	private static String url = "jdbc:mysql://dbinterfacesnixon.cn0swo6cw91x.us-east-1.rds.amazonaws.com:3306/" + bd;
	static Connection connection = null;
	private static Statement st;
	private static ResultSet rs;

	public void conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url, login, password);
			if (connection != null) {
				System.out.println("Conexion realizada con exito");
			} else {
				System.out.println("Conexion fallida");
			}
		} catch (ClassNotFoundException e) {
			System.err.println("Driver MySQL no encontrado");
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("Error al conectar con la base de datos");
			e.printStackTrace();
		}
	}

	public void ejecutarConsulta() throws SQLException {
		int id;
		String nombre, correo, telefono;
		Timestamp fechaRegistro;

		st = connection.createStatement();
		rs = st.executeQuery("SELECT id, nombre, correo, telefono, fecha_registro FROM clientes");

		while (rs.next()) {
			id = rs.getInt("id");
			nombre = rs.getString("nombre");
			correo = rs.getString("correo");
			telefono = rs.getString("telefono");
			fechaRegistro = rs.getTimestamp("fecha_registro");

			System.out.println("ID: " + id + " | Nombre: " + nombre + " | Correo: " + correo + " | Telefono: "
					+ telefono + " | Fecha Registro: " + fechaRegistro);
		}
	}

	public boolean insertarCliente(String nombre, String correo, String telefono) {
		String query = "INSERT INTO clientes (nombre, correo, telefono, fecha_registro) VALUES (?, ?, ?, NOW())";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setString(1, nombre);
			pstm.setString(2, correo);
			pstm.setString(3, telefono);

			int filasAfectadas = pstm.executeUpdate();
			System.out.println("Cliente insertado exitosamente. Filas afectadas: " + filasAfectadas);
			return true;
		} catch (SQLException e) {
			System.err.println("Error al insertar cliente");
			e.printStackTrace();
			return false;

		}
	}

	public void insertarClienteConFecha(String nombre, String correo, String telefono, Timestamp fechaRegistro) {
		String query = "INSERT INTO clientes (nombre, correo, telefono, fecha_registro) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setString(1, nombre);
			pstm.setString(2, correo);
			pstm.setString(3, telefono);
			pstm.setTimestamp(4, fechaRegistro);

			int filasAfectadas = pstm.executeUpdate();
			System.out.println("Cliente insertado exitosamente. Filas afectadas: " + filasAfectadas);
		} catch (SQLException e) {
			System.err.println("Error al insertar cliente");
			e.printStackTrace();
		}
	}

	public void cerrar() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (connection != null) {
				connection.close();
			}
			System.out.println("Conexion cerrada");
		} catch (SQLException e) {
			System.err.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

	public void borrarCliente(int id) {
		String query = "DELETE FROM clientes WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			int resultado = pstmt.executeUpdate();
			System.out.println("Cliente/s borrado con exito. Filas afectadas: " + resultado);
		} catch (SQLException e) {
			System.err.println("Error al borrar cliente");
			e.printStackTrace();
		}
	}

	public void actualizarCorreo(int id, String correo) {
		String query = "UPDATE clientes SET correo = ? WHERE id = ?";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setString(1, correo);
			pstm.setInt(2, id);
			int filasAfectadas = pstm.executeUpdate();
			System.out.println("Correo actualizado exitosamente. Filas afectadas: " + filasAfectadas);
		} catch (SQLException e) {
			System.err.println("Error al actualizar correo");
			e.printStackTrace();
		}
	}

	public void actualizarCliente(int id, String nombre, String correo, String telefono) {
		String query = "UPDATE clientes SET nombre = ?, correo = ?, telefono = ? WHERE id = ?";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setString(1, nombre);
			pstm.setString(2, correo);
			pstm.setString(3, telefono);
			pstm.setInt(4, id);
			int filasAfectadas = pstm.executeUpdate();
			System.out.println("Cliente actualizado exitosamente. Filas afectadas: " + filasAfectadas);
		} catch (SQLException e) {
			System.err.println("Error al actualizar cliente");
			e.printStackTrace();
		}
	}

	public void buscarClientePorId(int id) {
		String query = "SELECT id, nombre, correo, telefono, fecha_registro FROM clientes WHERE id = ?";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setInt(1, id);
			ResultSet resultado = pstm.executeQuery();

			if (resultado.next()) {
				System.out.println("ID: " + resultado.getInt("id"));
				System.out.println("Nombre: " + resultado.getString("nombre"));
				System.out.println("Correo: " + resultado.getString("correo"));
				System.out.println("Telefono: " + resultado.getString("telefono"));
				System.out.println("Fecha Registro: " + resultado.getTimestamp("fecha_registro"));
			} else {
				System.out.println("No se encontro cliente con ID: " + id);
			}
			resultado.close();
		} catch (SQLException e) {
			System.err.println("Error al buscar cliente");
			e.printStackTrace();
		}
	}

	public void buscarClientesPorNombre(String nombreBuscar) {
		String query = "SELECT id, nombre, correo, telefono, fecha_registro FROM clientes WHERE nombre LIKE ?";
		try (PreparedStatement pstm = connection.prepareStatement(query)) {
			pstm.setString(1, "%" + nombreBuscar + "%");
			ResultSet resultado = pstm.executeQuery();

			boolean encontrado = false;
			while (resultado.next()) {
				encontrado = true;
				System.out.println(
						"ID: " + resultado.getInt("id") + " | Nombre: " + resultado.getString("nombre") + " | Correo: "
								+ resultado.getString("correo") + " | Telefono: " + resultado.getString("telefono")
								+ " | Fecha Registro: " + resultado.getTimestamp("fecha_registro"));
			}

			if (!encontrado) {
				System.out.println("No se encontraron clientes con nombre similar a: " + nombreBuscar);
			}
			resultado.close();
		} catch (SQLException e) {
			System.err.println("Error al buscar clientes");
			e.printStackTrace();
		}
	}
}