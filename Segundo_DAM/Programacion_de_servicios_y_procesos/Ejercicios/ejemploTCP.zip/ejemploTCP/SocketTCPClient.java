package ejemploTCP;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketTCPClient {

	private String serverIP;
	private int serverPort;
	private Socket socket;
	private InputStream is;
	private OutputStream os;

	public SocketTCPClient(String serverIP, int serverPort) {
		this.serverIP = serverIP;
		this.serverPort = serverPort;
	}

	public void start() throws UnknownHostException, IOException {
		System.out.println("(Cliente) Estableciendo conexión...");
		socket = new Socket(serverIP, serverPort);//Creo un socket con la ip local y puerto
		os = socket.getOutputStream();
		is = socket.getInputStream();
		System.out.println("(Cliente) Conexión establecida.");
	}

	public void stop() throws IOException {
		System.out.println("(Cliente) Cerrando conexiones...");
		is.close();
		os.close();
		socket.close();
		System.out.println("(Cliente) Conexiones cerradas...");
	}

	public static void main(String[] args) {
		SocketTCPClient cliente = new SocketTCPClient("10.0.2.15", 49171);//Pongo la IP de mi ordenador en el que lo ejecuto
		try {
			cliente.start();
			cliente.os.write(100);//Mando 100 al servidor (output)
			System.out.println("Mensaje del servidor: " + cliente.is.read());//Leo entrada de datos del servidor (intput) y lo muestro
			cliente.stop();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

}
