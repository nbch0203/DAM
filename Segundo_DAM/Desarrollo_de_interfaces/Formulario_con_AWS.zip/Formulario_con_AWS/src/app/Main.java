package app;

import java.sql.SQLException;

import conexion.Conexion;
import vista.Vista;

public class Main {
	public static void main(String[] args) {
		
		
		Vista v= new Vista();
		
		v.
//		Conexion c = new Conexion();
//
//		c.conectar();
//		try {
//			c.ejecutarConsulta();
//			c.insertarCliente("nixon cruz", "nixonbcruzh@gmail.com", "611254628");
//			c.ejecutarConsulta();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		c.cerrar();
	}

}
